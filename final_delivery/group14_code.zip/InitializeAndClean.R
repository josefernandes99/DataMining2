library(tidyverse)
library(tidyr)
library(ggplot2)
library(dplyr)

# Read the dataset
chicago_crimes <- read_csv("Crimes___2017_to_Present.csv", show_col_types = FALSE)

chicago_crimes_clean <- chicago_crimes

capture.output(unique(chicago_crimes_clean$IUCR), file = "Uniques/IUCR_Uniques.txt")
capture.output(unique(chicago_crimes_clean$'Primary Type'), file = "Uniques/PrimaryType_Uniques.txt")
capture.output(unique(chicago_crimes_clean$Description), file = "Uniques/Description_Uniques.txt")
capture.output(unique(chicago_crimes_clean$'Location Description'), file = "Uniques/LocationDescription_Uniques.txt")
capture.output(unique(chicago_crimes_clean$'FBI Code'), file = "Uniques/FBICode_Uniques.txt")

# Remove rows with NA or empty values
chicago_crimes_clean <- chicago_crimes %>% drop_na()

# Correct Type names
chicago_crimes_clean$'Primary Type'[chicago_crimes_clean$'Primary Type' == "CRIM SEXUAL ASSAULT"] = "CRIMINAL SEXUAL ASSAULT"
chicago_crimes_clean$'Case Number'[chicago_crimes_clean$'Case Number' == ".JB299184"] = "JB299184"
chicago_crimes_clean$'Case Number'[chicago_crimes_clean$'Case Number' == "464266"] = "JB464266"
chicago_crimes_clean$District[chicago_crimes_clean$District == '16'] = "016"
chicago_crimes_clean$District[chicago_crimes_clean$District == '031'] = "016"

chicago_crimes_clean$Block <- toupper(chicago_crimes_clean$Block)

# Find and remove duplicate cases, keeping one instance
chicago_crimes_clean <- chicago_crimes_clean[!duplicated(chicago_crimes_clean$`Case Number`, fromLast = TRUE), ]

# Convert date and extract year and month.
# Also, count number of crimes per month
chicago_crimes_monthly <- chicago_crimes_clean %>%
  mutate(Date = as.Date(Date, format = "%Y-%m-%d")) %>%
  mutate(YearMonth = floor_date(Date, "month")) %>%
  count(YearMonth) # number of cases per month

# Separate "Date" Column by Day, Month, Year and Hour
chicago_crimes_clean$Date <- sub(" ", "-", chicago_crimes_clean$Date)
chicago_crimes_clean <- separate(chicago_crimes_clean, Date, c("CrimeYear", "CrimeMonth", "CrimeDay", "CrimeHour"), sep = "-")
chicago_crimes_clean[, c("CrimeDay", "CrimeMonth", "CrimeYear")] <- sapply(chicago_crimes_clean[, c("CrimeDay", "CrimeMonth", "CrimeYear")], as.numeric)

# Separate "Updated On" Column by Day, Month, Year and Hour
chicago_crimes_clean$'Updated On' <- strptime(chicago_crimes_clean$'Updated On',format="%m/%d/%Y %I:%M:%S %p")
chicago_crimes_clean$'Updated On' <- sub(" ", "-", chicago_crimes_clean$'Updated On')
chicago_crimes_clean <- separate(chicago_crimes_clean, 'Updated On', c("UpdateYear", "UpdateMonth", "UpdateDay", "UpdateHour"), sep = "-")
chicago_crimes_clean[, c("UpdateDay", "UpdateMonth", "UpdateYear")] <- sapply(chicago_crimes_clean[, c("UpdateDay", "UpdateMonth", "UpdateYear")], as.numeric)

# Convert CrimeTime to Integer
chicago_crimes_clean <- separate(chicago_crimes_clean, CrimeHour, c("Hour1", "Minute1", "Second1"), sep = ":")
chicago_crimes_clean$CrimeTime <- as.numeric(chicago_crimes_clean$Hour1)*60*60 + as.numeric(chicago_crimes_clean$Minute1)*60 + as.numeric(chicago_crimes_clean$Second1)
chicago_crimes_clean[ ,c('Hour1', 'Minute1', 'Second1')] <- list(NULL)

# Convert UpdateTime to Integer
chicago_crimes_clean <- separate(chicago_crimes_clean, UpdateHour, c("Hour2", "Minute2", "Second2"), sep = ":")
chicago_crimes_clean$UpdateTime <- as.numeric(chicago_crimes_clean$Hour2)*60*60 + as.numeric(chicago_crimes_clean$Minute2)*60 + as.numeric(chicago_crimes_clean$Second2)
chicago_crimes_clean[ ,c('Hour2', 'Minute2', 'Second2')] <- list(NULL)

#chicago_crimes_clean[ ,c('ID', 'Case Number', 'District', 'Beat', 'Ward', 'Community Area', 'Description')] <- list(NULL)