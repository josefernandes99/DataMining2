library(tidyverse)
library(tidyr)
library(ggplot2)
library(dplyr)
library(scales)
library(RColorBrewer)

source("InitializeAndClean.R")

# Create a basic map of Chicago
map <- ggplot() +
  geom_polygon(aes(x = c(-87.95, -87.5, -87.5, -87.95),
                   y = c(41.6, 41.6, 42.05, 42.05)), fill = "black") +
  coord_map(xlim = c(-87.95, -87.5), ylim = c(41.6, 42.05)) +
  theme_void()

# Plot the latitude and longitude points as a layer on the map
crimePoints <- geom_point(data = chicago_crimes_clean, aes(x = Longitude, y = Latitude), color = "red", size = 0.01, alpha = 0.3)

# Combine the map and points
CrimesInChicago <- map + crimePoints
ggsave("Plots/chicagoCrimeLocations.jpeg", CrimesInChicago)

# Create the plot
start_date <- min(chicago_crimes_monthly$YearMonth)
end_date <- max(chicago_crimes_monthly$YearMonth)
month_labels <- seq(from = start_date, to = end_date, by = "1 month")
monthly_plot <- ggplot(chicago_crimes_monthly, aes(x = YearMonth, y = n)) +
  geom_line() +
  geom_point() +
  labs(title = "Evolução dos Crimes em Chicago",
       x = "Mês",
       y = "Contagem de Crimes") +
  scale_x_date(breaks = month_labels, labels = scales::date_format("%Y-%m")) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))
ggsave("Plots/EvolutionCrimesChicago.jpeg", monthly_plot, width = 10, height = 5)

# Filter rows for each year
crimePoints2017 <- subset(chicago_crimes_clean, CrimeYear == 2017)
crimePoints2018 <- subset(chicago_crimes_clean, CrimeYear == 2018)
crimePoints2019 <- subset(chicago_crimes_clean, CrimeYear == 2019)
crimePoints2020 <- subset(chicago_crimes_clean, CrimeYear == 2020)
crimePoints2021 <- subset(chicago_crimes_clean, CrimeYear == 2021)
crimePoints2022 <- subset(chicago_crimes_clean, CrimeYear == 2022)
crimePoints2023 <- subset(chicago_crimes_clean, CrimeYear == 2023)

# Calculate the frequency of crimes for each District
district_frequency <- table(chicago_crimes_clean$District)

# Find the minimum and maximum frequency
min_frequency <- min(district_frequency)
max_frequency <- max(district_frequency)

colors <- c("#FFFFCC", "#FFFF99", "#FFFF66", "#FFFF33", "#FFFF00", "#FFEE00", "#FFDD00", "#FFCC00", "#FFBB00", "#FFAA00", "#FF9900", "#FF8800", "#FF7700", "#FF6600", "#FF5500", "#FF4400", "#FF3300", "#FF2200", "#FF1100", "#FF0000", "#EE0000", "#DD0000", "#CC0000", "#BB0000", "#AA0000", "#990000")

# Function to map frequency to a color gradient
map_frequency_to_color <- function(frequency, max_frequency) {
  
  # Calculate the index based on the frequency rank
  index <- floor((frequency - 1) / max_frequency * (length(colors) - 1))
  
  # Select the color from the array based on the index
  color <- colors[index]
  
  return(color)
}

# Add a new column to each data frame with the color based on frequency
crimePoints2017$Color <- map_frequency_to_color(district_frequency[as.character(crimePoints2017$District)], max_frequency)
crimePoints2018$Color <- map_frequency_to_color(district_frequency[as.character(crimePoints2018$District)], max_frequency)
crimePoints2019$Color <- map_frequency_to_color(district_frequency[as.character(crimePoints2019$District)], max_frequency)
crimePoints2020$Color <- map_frequency_to_color(district_frequency[as.character(crimePoints2020$District)], max_frequency)
crimePoints2021$Color <- map_frequency_to_color(district_frequency[as.character(crimePoints2021$District)], max_frequency)
crimePoints2022$Color <- map_frequency_to_color(district_frequency[as.character(crimePoints2022$District)], max_frequency)
crimePoints2023$Color <- map_frequency_to_color(district_frequency[as.character(crimePoints2023$District)], max_frequency)

# Plot the latitude and longitude points as a layer on the map
crimePoints2017 <- geom_point(data = crimePoints2017, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 1)
crimePoints2018 <- geom_point(data = crimePoints2018, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 1)
crimePoints2019 <- geom_point(data = crimePoints2019, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 1)
crimePoints2020 <- geom_point(data = crimePoints2020, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 1)
crimePoints2021 <- geom_point(data = crimePoints2021, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 1)
crimePoints2022 <- geom_point(data = crimePoints2022, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 1)
crimePoints2023 <- geom_point(data = crimePoints2023, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 1)

# Combine the map and points
CrimesInChicagoByYear <- map + scale_color_manual(values = colors) + crimePoints2017 + crimePoints2018 + crimePoints2019 + crimePoints2020 + crimePoints2021 + crimePoints2022 + crimePoints2023

# Remove legends
CrimesInChicagoByYear <- CrimesInChicagoByYear + guides(color = "none")

ggsave("Plots/chicagoCrimeLocationsByYear.jpeg", CrimesInChicagoByYear)

CrimesInChicago2017 <- map+ scale_color_manual(values = colors) + crimePoints2017 + guides(color = "none")
ggsave("Plots/chicagoCrimeLocations2017.jpeg", CrimesInChicago2017)

CrimesInChicago2018 <- map + scale_color_manual(values = colors) + crimePoints2018 + guides(color = "none")
ggsave("Plots/chicagoCrimeLocations2018.jpeg", CrimesInChicago2018)

CrimesInChicago2019 <- map + scale_color_manual(values = colors) + crimePoints2019 + guides(color = "none")
ggsave("Plots/chicagoCrimeLocations2019.jpeg", CrimesInChicago2019)

CrimesInChicago2020 <- map + scale_color_manual(values = colors) + crimePoints2020 + guides(color = "none")
ggsave("Plots/chicagoCrimeLocations2020.jpeg", CrimesInChicago2020)

CrimesInChicago2021 <- map + scale_color_manual(values = colors) + crimePoints2021 + guides(color = "none")
ggsave("Plots/chicagoCrimeLocations2021.jpeg", CrimesInChicago2021)

CrimesInChicago2022 <- map + scale_color_manual(values = colors) + crimePoints2022 + guides(color = "none")
ggsave("Plots/chicagoCrimeLocations2022.jpeg", CrimesInChicago2022)

CrimesInChicago2023 <- map + scale_color_manual(values = colors) + crimePoints2023 + guides(color = "none")
ggsave("Plots/chicagoCrimeLocations2023.jpeg", CrimesInChicago2023)

# Create a frequency table of unique values in the "FBI Code" column
fbi_code_freq <- table(chicago_crimes_clean$`FBI Code`)

# Convert the frequency table into a data frame
fbi_code_df <- as.data.frame(fbi_code_freq)

# Rename the columns
colnames(fbi_code_df) <- c("FBI Code", "Frequency")

# Sort the data frame by frequency in descending order
fbi_code_df <- fbi_code_df[order(fbi_code_df$Frequency, decreasing = TRUE), ]

# Plot the frequency plot using ggplot2
FBICodeFrequency <- ggplot(fbi_code_df, aes(x = `FBI Code`, y = Frequency)) +
  geom_bar(stat = "identity", fill = "blue") +
  xlab("Código FBI") +
  ylab("Frequência") +
  ggtitle("Frequência dos Valores Únicos do FBI") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_y_continuous(labels = comma)

ggsave("Plots/FBICodeFrequency.jpeg", FBICodeFrequency)

# Get unique values in the "FBI Code" column
unique_fbi_codes <- unique(chicago_crimes_clean$`FBI Code`)

# Create an empty list to store results
FBICodeFinal <- list()

# Iterate over each unique FBI Code
for (fbi_code in unique_fbi_codes) {
  # Get unique Primary Types for the current FBI Code
  unique_primary_types <- unique(chicago_crimes_clean$`Primary Type`[chicago_crimes_clean$`FBI Code` == fbi_code])
  
  # Combine the Primary Types into a string
  primary_types_string <- paste(unique_primary_types, collapse = ", ")
  
  # Create the output string
  output_string <- paste(fbi_code, " = ", primary_types_string)
  
  # Add the output string to the final list
  FBICodeFinal[[fbi_code]] <- output_string
}

# Export the results to a text file
capture.output(FBICodeFinal, file = "Uniques/FBICodesPrimaryTypes.txt")

# Get unique values in the "FBI Code" column
unique_fbi_codes <- unique(chicago_crimes_clean$`FBI Code`)

# Create an empty data frame to store associations
FBICodePrimaryTypes <- data.frame(FBI_Code = character(),
                                  Primary_Type = character(),
                                  stringsAsFactors = FALSE)

# Iterate over each unique FBI Code
for (fbi_code in unique_fbi_codes) {
  # Get unique Primary Types for the current FBI Code
  unique_primary_types <- unique(chicago_crimes_clean$`Primary Type`[chicago_crimes_clean$`FBI Code` == fbi_code])
  
  # Create a data frame for associations
  associations <- data.frame(FBI_Code = fbi_code, Primary_Type = unique_primary_types)
  
  # Append associations to the main data frame
  FBICodePrimaryTypes <- rbind(FBICodePrimaryTypes, associations)
}

# Create a grid plot with crosses indicating associations
plot <- ggplot(FBICodePrimaryTypes, aes(x = FBI_Code, y = Primary_Type)) +
  geom_point(color = "red", size = 3) +
  xlab("Código FBI") +
  ylab("Tipo Principal") +
  coord_equal() +
  theme_bw() +
  theme(panel.grid.major = element_line(color = "gray", linetype = "dashed"),
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 45, hjust = 1))

# Export the plot as a JPEG file
ggsave("Plots/FBICodePrimaryTypes.jpeg", plot)

# Create a basic map of Chicago
map <- ggplot() +
  geom_polygon(aes(x = c(-87.95, -87.5, -87.5, -87.95),
                   y = c(41.6, 41.6, 42.05, 42.05)), fill = "black") +
  coord_map(xlim = c(-87.95, -87.5), ylim = c(41.6, 42.05)) +
  theme_void()

# Filter rows for each year
crimePoints2017 <- subset(chicago_crimes_clean, CrimeYear == 2017)
crimePoints2018 <- subset(chicago_crimes_clean, CrimeYear == 2018)
crimePoints2019 <- subset(chicago_crimes_clean, CrimeYear == 2019)
crimePoints2020 <- subset(chicago_crimes_clean, CrimeYear == 2020)
crimePoints2021 <- subset(chicago_crimes_clean, CrimeYear == 2021)
crimePoints2022 <- subset(chicago_crimes_clean, CrimeYear == 2022)
crimePoints2023 <- subset(chicago_crimes_clean, CrimeYear == 2023)

# Calculate the frequency of arrests
arrest_frequency <- table(chicago_crimes_clean$Arrest)

# Find the minimum and maximum frequency
min_frequency <- min(arrest_frequency)
max_frequency <- max(arrest_frequency)

# Define the two hex colors based on Arrest column
color_arrest <- c("#FFFFCC", "#990000")

# Add a new column to each data frame with the color based on frequency
crimePoints2017 <- crimePoints2017 %>%
  mutate(Color = ifelse(Arrest, color_arrest[2], color_arrest[1]))
crimePoints2018 <- crimePoints2018 %>%
  mutate(Color = ifelse(Arrest, color_arrest[2], color_arrest[1]))
crimePoints2019 <- crimePoints2019 %>%
  mutate(Color = ifelse(Arrest, color_arrest[2], color_arrest[1]))
crimePoints2020 <- crimePoints2020 %>%
  mutate(Color = ifelse(Arrest, color_arrest[2], color_arrest[1]))
crimePoints2021 <- crimePoints2021 %>%
  mutate(Color = ifelse(Arrest, color_arrest[2], color_arrest[1]))
crimePoints2022 <- crimePoints2022 %>%
  mutate(Color = ifelse(Arrest, color_arrest[2], color_arrest[1]))
crimePoints2023 <- crimePoints2023 %>%
  mutate(Color = ifelse(Arrest, color_arrest[2], color_arrest[1]))

# Plot the latitude and longitude points as a layer on the map
crimePoints2017 <- geom_point(data = crimePoints2017, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)
crimePoints2018 <- geom_point(data = crimePoints2018, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)
crimePoints2019 <- geom_point(data = crimePoints2019, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)
crimePoints2020 <- geom_point(data = crimePoints2020, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)
crimePoints2021 <- geom_point(data = crimePoints2021, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)
crimePoints2022 <- geom_point(data = crimePoints2022, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)
crimePoints2023 <- geom_point(data = crimePoints2023, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)

# Combine the map and points
CrimesInChicagoByYear <- map + scale_color_manual(values = color_arrest) + crimePoints2017 + crimePoints2018 + crimePoints2019 + crimePoints2020 + crimePoints2021 + crimePoints2022 + crimePoints2023

# Remove legends
CrimesInChicagoByYear <- CrimesInChicagoByYear + guides(color = "none")

ggsave("Plots/chicagoCrimeLocationsByYearArrest.jpeg", CrimesInChicagoByYear)

# Filter rows for each year
crimePoints2017 <- subset(chicago_crimes_clean, CrimeYear == 2017)
crimePoints2018 <- subset(chicago_crimes_clean, CrimeYear == 2018)
crimePoints2019 <- subset(chicago_crimes_clean, CrimeYear == 2019)
crimePoints2020 <- subset(chicago_crimes_clean, CrimeYear == 2020)
crimePoints2021 <- subset(chicago_crimes_clean, CrimeYear == 2021)
crimePoints2022 <- subset(chicago_crimes_clean, CrimeYear == 2022)
crimePoints2023 <- subset(chicago_crimes_clean, CrimeYear == 2023)

# Calculate the frequency of arrests
Domestic_frequency <- table(chicago_crimes_clean$Domestic)

# Find the minimum and maximum frequency
min_frequency <- min(Domestic_frequency)
max_frequency <- max(Domestic_frequency)

# Define the two hex colors based on Domestic column
color_Domestic <- c("#FFFFCC", "#990000")

# Add a new column to each data frame with the color based on frequency
crimePoints2017 <- crimePoints2017 %>%
  mutate(Color = ifelse(Domestic, color_Domestic[2], color_Domestic[1]))
crimePoints2018 <- crimePoints2018 %>%
  mutate(Color = ifelse(Domestic, color_Domestic[2], color_Domestic[1]))
crimePoints2019 <- crimePoints2019 %>%
  mutate(Color = ifelse(Domestic, color_Domestic[2], color_Domestic[1]))
crimePoints2020 <- crimePoints2020 %>%
  mutate(Color = ifelse(Domestic, color_Domestic[2], color_Domestic[1]))
crimePoints2021 <- crimePoints2021 %>%
  mutate(Color = ifelse(Domestic, color_Domestic[2], color_Domestic[1]))
crimePoints2022 <- crimePoints2022 %>%
  mutate(Color = ifelse(Domestic, color_Domestic[2], color_Domestic[1]))
crimePoints2023 <- crimePoints2023 %>%
  mutate(Color = ifelse(Domestic, color_Domestic[2], color_Domestic[1]))

# Plot the latitude and longitude points as a layer on the map
crimePoints2017 <- geom_point(data = crimePoints2017, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)
crimePoints2018 <- geom_point(data = crimePoints2018, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)
crimePoints2019 <- geom_point(data = crimePoints2019, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)
crimePoints2020 <- geom_point(data = crimePoints2020, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)
crimePoints2021 <- geom_point(data = crimePoints2021, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)
crimePoints2022 <- geom_point(data = crimePoints2022, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)
crimePoints2023 <- geom_point(data = crimePoints2023, aes(x = Longitude, y = Latitude, color = Color), size = 0.001, alpha = 0.5)

# Combine the map and points
CrimesInChicagoByYear <- map + scale_color_manual(values = color_Domestic) + crimePoints2017 + crimePoints2018 + crimePoints2019 + crimePoints2020 + crimePoints2021 + crimePoints2022 + crimePoints2023

# Remove legends
CrimesInChicagoByYear <- CrimesInChicagoByYear + guides(color = "none")

ggsave("Plots/chicagoCrimeLocationsByYearDomestic.jpeg", CrimesInChicagoByYear)

chicago_crimes_clean$isCrime = TRUE

# Create an empty data frame for false crimes
false_crimes <- data.frame(
  CrimeYear = integer(),
  CrimeMonth = integer(),
  CrimeDay = integer(),
  Block = character(),
  District = character(),
  Latitude = numeric(),
  Longitude = numeric(),
  CrimeTime = integer(),
  Beat = character(),           # Add Beat column
  Ward = character(),           # Add Ward column
  CommunityArea = character(),  # Add CommunityArea column
  stringsAsFactors = FALSE      # Ensure strings are treated as character vectors
)

# Set random seed for reproducibility
set.seed(123)

# Generate false crimes data
for (i in 1:10000) {  # Change the number (1000) as desired
  
  print(i)
  
  # Generate random values for each column
  crime_year <- sample(2017:2023, 1)
  crime_month <- sample(1:12, 1)
  crime_day <- ifelse(crime_month == 3, sample(1:26, 1), sample(1:30, 1))
  
  block <- sample(unique(chicago_crimes_clean$Block), 1)
  
  block_rows <- which(chicago_crimes_clean$Block == block)
  beat <- sample(unique(chicago_crimes_clean$Beat[block_rows]), 1)
  
  beat_rows <- which(chicago_crimes_clean$Beat == beat)
  ward <- sample(unique(chicago_crimes_clean$Ward[beat_rows]), 1)
  
  ward_rows <- which(chicago_crimes_clean$Ward == ward)
  community_area <- sample(unique(chicago_crimes_clean$'Community Area'[ward_rows]), 1)
  
  community_area_rows <- which(chicago_crimes_clean$'Community Area' == community_area)
  district <- sample(unique(chicago_crimes_clean$District[community_area_rows]), 1)
  
  lat_long_row <- sample(block_rows, 1)
  latitude <- chicago_crimes_clean[lat_long_row, "Latitude"]
  longitude <- chicago_crimes_clean[lat_long_row, "Longitude"]
  
  crime_time <- sample(0:86000, 1)
  
  # Append the generated values to the false_crimes data frame
  false_crimes <- rbind(
    false_crimes,
    data.frame(
      CrimeYear = crime_year,
      CrimeMonth = crime_month,
      CrimeDay = crime_day,
      Block = block,
      District = district,
      Latitude = latitude,
      Longitude = longitude,
      CrimeTime = crime_time,
      Beat = beat,
      Ward = ward,
      CommunityArea = community_area,
      stringsAsFactors = FALSE  # Ensure strings are treated as character vectors
    )
  )
}



false_crimes$isCrime <- FALSE

num_rows <- 10000  # Number of random rows to sample
total_rows <- nrow(chicago_crimes_clean)
random_indices <- sample(total_rows, num_rows)
true_crimes <- chicago_crimes_clean[random_indices, ]

true_crimes$'CommunityArea' = true_crimes$'Community Area'

false_crimes$CrimeYear <- as.numeric(false_crimes$CrimeYear)
false_crimes$CrimeMonth <- as.numeric(false_crimes$CrimeMonth)
false_crimes$CrimeDay <- as.numeric(false_crimes$CrimeDay)
false_crimes$CrimeTime <- as.numeric(false_crimes$CrimeTime)

true_crimes$ID <- NULL
true_crimes$'Case Number' <- NULL
true_crimes$IUCR <- NULL
true_crimes$'Primary Type' <- NULL
true_crimes$Description <- NULL
true_crimes$'Location Description' <- NULL
true_crimes$Arrest <- NULL
true_crimes$Domestic <- NULL
true_crimes$'FBI Code' <- NULL
true_crimes$Year <- NULL
true_crimes$UpdateYear <- NULL
true_crimes$UpdateMonth <- NULL
true_crimes$UpdateDay <- NULL
true_crimes$UpdateTime <- NULL
true_crimes$'Community Area' <- NULL

general_crimes <- rbind(true_crimes, false_crimes)

total_rows <- nrow(general_crimes)
random_indices <- sample(total_rows)
general_crimes <- general_crimes[random_indices, ]

rm(random_indices, total_rows, arrest, domestic, fbi_code, iucr, latitude, location_desc, longitude, primary_type, block, crime_day, crime_month, crime_time, crime_year, district, i, iucr_row, lat_long_row, update_day, update_month, update_time, update_year, keep, num_rows)
rm(associations, end_date, start_date, month_labels, monthly_plot, crimePoints, CrimesInChicago, chicago_crimes_monthly, crimePoints2017, crimePoints2018, crimePoints2019, crimePoints2020, crimePoints2021, crimePoints2022, crimePoints2023, CrimesInChicago2017, CrimesInChicago2018, CrimesInChicago2019, CrimesInChicago2020, CrimesInChicago2021, CrimesInChicago2022, CrimesInChicago2023, CrimesInChicagoByYear, fbi_code_df, FBICodeFinal, FBICodeFrequency, FBICodePrimaryTypes, map, plot, arrest_frequency, color_arrest, color_Domestic, colors, district_frequency, Domestic_frequency, fbi_code, fbi_code_freq, max_frequency, min_frequency, output_string, primary_types_string, unique_fbi_codes, unique_primary_types, map_frequency_to_color)

source("MachineLearning.R")
