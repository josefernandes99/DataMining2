library(e1071)

# Assuming the general_crimes dataframe has a 'isCrime' column representing the target variable

# Convert 'isCrime' column to logical
general_crimes$isCrime <- as.logical(general_crimes$isCrime)

# Splitting the data into training and testing sets (70% training, 30% testing)
set.seed(42)  # For reproducibility
train_indices <- sample(1:nrow(general_crimes), 0.7 * nrow(general_crimes))
train_df <- general_crimes[train_indices, ]
test_df <- general_crimes[-train_indices, ]

# Creating the Naive Bayes model
model <- naiveBayes(isCrime ~ ., data = train_df)

# Predicting on the test set
predictions <- predict(model, newdata = test_df)

# Convert predictions to logical
predictions <- as.logical(predictions)

# Evaluation metrics
accuracy <- sum(predictions == test_df$isCrime) / nrow(test_df)
precision <- sum(predictions & test_df$isCrime) / sum(predictions)
recall <- sum(predictions & test_df$isCrime) / sum(test_df$isCrime)
f1 <- 2 * (precision * recall) / (precision + recall)

# Create a data frame for evaluation metrics
metrics <- data.frame(Metric = c("Accuracy", "Precision", "Recall", "F1 Score"),
                      Value = c(accuracy, precision, recall, f1))

# Create the Uniques folder if it doesn't exist
dir.create("Uniques", showWarnings = FALSE)

# Save the evaluation metrics results to a text file
file_path <- file.path("Uniques", "NBEvaluationResults.txt")
write.table(metrics, file = file_path, sep = "\t", row.names = FALSE, quote = FALSE)

# Print the evaluation metrics
cat("Evaluation Metrics:\n")
cat("---------------\n")
cat(paste(metrics$Metric, metrics$Value, sep = ": "), "\n")