library(tidyverse)
library(tidyr)
library(ggplot2)
library(dplyr)
library(scales)

## -- Reading and basic cleaning -------

source("InitializeAndClean.R")

colors <- c("#FF0000", "#00FF00", "#0000FF", "#FFFF00", "#FF00FF", "#00FFFF", "#800000", "#008000", "#000080", "#808000", "#800080", "#008080", "#FF4500", "#FF69B4", "#FF6347", "#FF8C00", "#FFD700", "#FFA500", "#FF1493", "#FF00FF", "#FFB6C1", "#FF7F50", "#FFA07A", "#FF8C69", "#FFDAB9", "#FFE4E1", "#FA8072", "#FF4500", "#FF69B4", "#FF6347", "#FF8C00", "#FFD700", "#FFA500", "#FF1493", "#FF00FF", "#FFB6C1", "#FF7F50", "#FFA07A", "#FF8C69", "#FFDAB9", "#FFE4E1", "#FA8072", "#8B0000", "#32CD32", "#0000CD", "#FFD700", "#BA55D3", "#9370DB", "#3CB371", "#7B68EE", "#00FA9A", "#48D1CC", "#C71585", "#191970", "#B22222", "#228B22", "#DC143C", "#00FF00", "#FFD700", "#FFA500", "#FF1493", "#00BFFF", "#696969", "#1E90FF", "#B22222", "#228B22", "#DC143C", "#00FF00", "#FFD700", "#FFA500", "#FF1493", "#00BFFF", "#696969", "#1E90FF", "#FFFF00", "#8A2BE2", "#00FF7F", "#FF7F50", "#6495ED", "#FF4500", "#87CEEB", "#FF69B4", "#1E90FF", "#FFD700", "#FFA500", "#FF1493", "#00BFFF", "#696969", "#1E90FF", "#FFFF00", "#8A2BE2", "#00FF7F", "#FF7F50", "#6495ED", "#FF4500", "#87CEEB", "#FF69B4")

# Create a basic map of Chicago
map <- ggplot() +
  geom_polygon(aes(x = c(-87.95, -87.5, -87.5, -87.95),
                   y = c(41.6, 41.6, 42.05, 42.05)), fill = "black") +
  coord_map(xlim = c(-87.95, -87.5), ylim = c(41.6, 42.05)) +
  theme_void()

# Plot the latitude and longitude points as a layer on the map
crimePoints <- geom_point(data = chicago_crimes_clean, aes(x = Longitude, y = Latitude), color = "red", size = 0.01, alpha = 0.3)

# Combine the map and points
CrimesInChicago <- map + crimePoints
ggsave("Plots/chicagoCrimeLocations.jpeg", CrimesInChicago)

# Create the plot
start_date <- min(chicago_crimes_monthly$YearMonth)
end_date <- max(chicago_crimes_monthly$YearMonth)
month_labels <- seq(from = start_date, to = end_date, by = "1 month")
monthly_plot <- ggplot(chicago_crimes_monthly, aes(x = YearMonth, y = n)) +
  geom_line() +
  geom_point() +
  labs(title = "Evolução dos Crimes em Chicago",
       x = "Mês",
       y = "Contagem de Crimes") +
  scale_x_date(breaks = month_labels, labels = scales::date_format("%Y-%m")) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))
ggsave("Plots/EvolutionCrimesChicago.jpeg", monthly_plot, width = 10, height = 5)

# Filter rows for each year
crimePoints2017 <- subset(chicago_crimes_clean, CrimeYear == 2017)
crimePoints2018 <- subset(chicago_crimes_clean, CrimeYear == 2018)
crimePoints2019 <- subset(chicago_crimes_clean, CrimeYear == 2019)
crimePoints2020 <- subset(chicago_crimes_clean, CrimeYear == 2020)
crimePoints2021 <- subset(chicago_crimes_clean, CrimeYear == 2021)
crimePoints2022 <- subset(chicago_crimes_clean, CrimeYear == 2022)
crimePoints2023 <- subset(chicago_crimes_clean, CrimeYear == 2023)

# Plot the latitude and longitude points as a layer on the map
crimePoints2017 <- geom_point(data = crimePoints2017, aes(x = Longitude, y = Latitude), color = "red", size = 0.001, alpha = 1)
crimePoints2018 <- geom_point(data = crimePoints2018, aes(x = Longitude, y = Latitude), color = "blue", size = 0.001, alpha = 0.9)
crimePoints2019 <- geom_point(data = crimePoints2019, aes(x = Longitude, y = Latitude), color = "green", size = 0.001, alpha = 0.8)
crimePoints2020 <- geom_point(data = crimePoints2020, aes(x = Longitude, y = Latitude), color = "pink", size = 0.001, alpha = 0.7)
crimePoints2021 <- geom_point(data = crimePoints2021, aes(x = Longitude, y = Latitude), color = "yellow", size = 0.001, alpha = 0.3)
crimePoints2022 <- geom_point(data = crimePoints2022, aes(x = Longitude, y = Latitude), color = "orange", size = 0.001, alpha = 0.2)
crimePoints2023 <- geom_point(data = crimePoints2023, aes(x = Longitude, y = Latitude), color = "purple", size = 0.001, alpha = 0.1)

# Combine the map and points
CrimesInChicagoByYear <- map + crimePoints2017 + crimePoints2018 + crimePoints2019 + crimePoints2020 + crimePoints2021 + crimePoints2022 + crimePoints2023
ggsave("Plots/chicagoCrimeLocationsByYear.jpeg", CrimesInChicagoByYear)
CrimesInChicago2017 <- map + crimePoints2017
ggsave("Plots/chicagoCrimeLocations2017.jpeg", CrimesInChicago2017)
CrimesInChicago2018 <- map + crimePoints2018
ggsave("Plots/chicagoCrimeLocations2018.jpeg", CrimesInChicago2018)
CrimesInChicago2019 <- map + crimePoints2019
ggsave("Plots/chicagoCrimeLocations2019.jpeg", CrimesInChicago2019)
CrimesInChicago2020 <- map + crimePoints2020
ggsave("Plots/chicagoCrimeLocations2020.jpeg", CrimesInChicago2020)
CrimesInChicago2021 <- map + crimePoints2021
ggsave("Plots/chicagoCrimeLocations2021.jpeg", CrimesInChicago2021)
CrimesInChicago2022 <- map + crimePoints2022
ggsave("Plots/chicagoCrimeLocations2022.jpeg", CrimesInChicago2022)
CrimesInChicago2023<- map + crimePoints2023
ggsave("Plots/chicagoCrimeLocations2023.jpeg", CrimesInChicago2023)

# Create a frequency table of unique values in the "FBI Code" column
fbi_code_freq <- table(chicago_crimes_clean$`FBI Code`)

# Convert the frequency table into a data frame
fbi_code_df <- as.data.frame(fbi_code_freq)

# Rename the columns
colnames(fbi_code_df) <- c("FBI Code", "Frequency")

# Sort the data frame by frequency in descending order
fbi_code_df <- fbi_code_df[order(fbi_code_df$Frequency, decreasing = TRUE), ]

# Plot the frequency plot using ggplot2
FBICodeFrequency <- ggplot(fbi_code_df, aes(x = `FBI Code`, y = Frequency)) +
  geom_bar(stat = "identity", fill = "blue") +
  xlab("Código FBI") +
  ylab("Frequência") +
  ggtitle("Frequência dos Valores Únicos do FBI") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_y_continuous(labels = comma)

ggsave("Plots/FBICodeFrequency.jpeg", FBICodeFrequency)

# Get unique values in the "FBI Code" column
unique_fbi_codes <- unique(chicago_crimes_clean$`FBI Code`)

# Create an empty list to store results
FBICodeFinal <- list()

# Iterate over each unique FBI Code
for (fbi_code in unique_fbi_codes) {
  # Get unique Primary Types for the current FBI Code
  unique_primary_types <- unique(chicago_crimes_clean$`Primary Type`[chicago_crimes_clean$`FBI Code` == fbi_code])
  
  # Combine the Primary Types into a string
  primary_types_string <- paste(unique_primary_types, collapse = ", ")
  
  # Create the output string
  output_string <- paste(fbi_code, " = ", primary_types_string)
  
  # Add the output string to the final list
  FBICodeFinal[[fbi_code]] <- output_string
}

# Export the results to a text file
capture.output(FBICodeFinal, file = "Uniques/FBICodesPrimaryTypes.txt")

## ------------------------------------

# Delete last month of dataset (outlier) too low number
#chicago_crimes_clean <- subset(chicago_crimes_clean, CrimeYear != "2023" & CrimeMonth != "04")

rm(end_date, start_date, month_labels, monthly_plot, crimePoints, crimePoints2017, crimePoints2018, crimePoints2019, crimePoints2020, crimePoints2021, crimePoints2022, crimePoints2023, CrimesInChicago, CrimesInChicago2017, CrimesInChicago2018, CrimesInChicago2019, CrimesInChicago2020, CrimesInChicago2021, CrimesInChicago2022, CrimesInChicago2023, CrimesInChicagoByYear)

